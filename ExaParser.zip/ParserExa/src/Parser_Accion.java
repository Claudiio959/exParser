
public class Parser_Accion {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Parser parser = new Parser();
		parser.ParseFicheroXml("biblioteca.xml");
		parser.parseDocument();
		parser.print();
	}

}
