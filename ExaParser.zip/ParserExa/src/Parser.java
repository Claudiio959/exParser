import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

public class Parser {
	private Document dom = null;
	private ArrayList<Accion> acciones = null;
	
	public Parser() {
		acciones= new ArrayList<>();
	}
	
	public void ParseFicheroXml(String fichero) {
		DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
	try {
		DocumentBuilder db = dbf.newDocumentBuilder();
		
		dom = db.parse(fichero);
	} catch (ParserConfigurationException pce) {
		pce.printStackTrace();
	} catch (SAXException se) {
		se.printStackTrace();
	} catch (IOException ioe) {
		ioe.printStackTrace();
	}

}
	
	public void parseDocument() {
		Element docEle = dom.getDocumentElement();

	
		NodeList nl = docEle.getElementsByTagName("accion");
		if (nl != null && nl.getLength() > 0) {
			for (int i = 0; i < nl.getLength(); i++) {

				Element el = (Element) nl.item(i);
		
				Accion p = getAccion(el);

				acciones.add(p);

	}
	}
	
	}
	

	private Accion getAccion(Element AccionEle) {
				String nombre = getTextValue(AccionEle, "nombre");
				int cantidad = getIntValue(AccionEle, "cantidad");
				int precio = getIntValue(AccionEle, "precio");

				Accion e = new Accion(nombre, cantidad, precio);

				return e;
	}
	
	private String getTextValue(Element ele, String tagName) {
		String textVal = null;
		NodeList nl = ele.getElementsByTagName(tagName);
		if (nl != null && nl.getLength() > 0) {
			Element el = (Element) nl.item(0);
			textVal = el.getFirstChild().getNodeValue();
		}
		return textVal;
	}
	
	private int getIntValue(Element ele, String tagName) {
		return Integer.parseInt(getTextValue(ele, tagName));
	}
	
	public void print() {

		for(Accion aux: acciones) {
			aux.mensaje();
			System.out.println(aux.mensaje());
		}
		
	}
	
}

